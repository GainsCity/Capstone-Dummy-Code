package com.example.graphtest;

import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.Bundle;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    LineGraphSeries<DataPoint> series;
    LineGraphSeries<DataPoint> series2;

    static final UUID mUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BluetoothAdapter btAdapter = BluetoothAdapter.getDefaultAdapter();
        System.out.println(btAdapter.getBondedDevices()); /*This line will output what devices are connected to the android device,
         should display that the HC05 module is connected when stablish connection. Check "System.out" to MAC address the coords from the "Run" tab*/





        /*Now creating a bluetooth opbject for the HC-05 module*/


        BluetoothDevice hc05 = btAdapter.getRemoteDevice("00:14:03:05:0D:6D");
        System.out.println(hc05.getName());
        /*The previous line will just check if the Hc05 is correctly paired by prinitn gits name on the run window,
         * again, check for "System.out"*/

        /*Creating a socket fro communication between the bluetooth devices*/
        BluetoothSocket btSocket = null;
        /*Creating a do loop that will repeat 3 times, to ensure connection is made*/
        int counter = 0;
        do {
            try {
                btSocket = hc05.createRfcommSocketToServiceRecord(mUUID);
                /*Check if the socket has actually been created, will print again on System out "bluetooth socket"*/

                System.out.println(btSocket);
                /*Connecting to the hc05 server*/
                btSocket.connect();
                /*prints in sys out to say if its connected or not*/
                System.out.println(btSocket.isConnected());
            } catch (IOException e) {
                e.printStackTrace();
            }
            counter++;
        } while (!btSocket.isConnected() && counter < 3);
        /*Now that connection is established, lets exchange data*/
        /*Depending on what you sned the arduino as an initiator, change the character in the .write command*/
        try {
            /*OUTPUT STREAM TO SEND DATA TO ARDUINO*/
            OutputStream outputStream = btSocket.getOutputStream();
            outputStream.write(48);
            System.out.println("dubby");

        } catch (IOException e) {
            e.printStackTrace();
        }

        /*This is the juice, the input stream, the receiviung end*/

        InputStream inputStream = null;
        try {
            inputStream = btSocket.getInputStream();
            inputStream.skip(inputStream.available());

            /*This next for loop is made in order to tell studio to read the data that it is expected to be receiving
             * In this example, the stream is expected to be 26 characters*/

            for (int i = 0; i < 26; i++) {

                byte b = (byte) inputStream.read();
                /*Prints out to the console to see if the data is being received*/
                System.out.println((char) b);


            }
        } catch (IOException e) {
            e.printStackTrace();

        }
        /*FLushing the input stream buffer, in case there is any data "leftover"*/





        /*Upon execution of our code, we will want to close this connection, so:*/
        /*Its a throwable, so need to be surrounded by a try and catch handler*/
        try {
            btSocket.close();
            /*prints in sys out to say if its connected or not*/

        } catch (IOException e) {
            e.printStackTrace();
        }

        double y, x;
        double a, b;
        x = -5.0;
        a = -5.0;
        GraphView graph = (GraphView) findViewById(R.id.graph);
        series = new LineGraphSeries<DataPoint>();
        for (int i = 0; i < 500; i++) {
            x = x + 0.1;
            y = Math.sin(x);
            series.appendData(new DataPoint(x, y), true, 500);
            graph.addSeries(series);
        }
        GraphView graph2 = (GraphView) findViewById(R.id.graph2);
        series2 = new LineGraphSeries<DataPoint>();
        for (int i = 0; i < 500; i++) {
            a = a + 0.1;
            b = Math.cos(a);
            series2.appendData(new DataPoint(a, b), true, 500);
            graph2.addSeries(series2);
        }

    }


}



